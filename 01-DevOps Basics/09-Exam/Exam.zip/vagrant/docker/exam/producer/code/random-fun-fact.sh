#!/bin/bash

/usr/local/bin/python3 /app/random-fun-fact.py
